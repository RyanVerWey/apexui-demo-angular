import core from "./tokens/core.json";
import dark from "./tokens/dark.json";
import enterprise from "./tokens/enterprise.json";
import light from "./tokens/light.json";

export const tokenSets = {
  core,
  light,
  dark,
  enterprise
} as const;

export type TokenSetName = keyof typeof tokenSets;
