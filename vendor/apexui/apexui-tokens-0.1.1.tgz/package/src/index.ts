import amberDark from "./tokens/amber-dark.json";
import amberLight from "./tokens/amber-light.json";
import apexDark from "./tokens/apex-dark.json";
import apexLight from "./tokens/apex-light.json";
import conceptDark from "./tokens/concept-dark.json";
import conceptLight from "./tokens/concept-light.json";
import core from "./tokens/core.json";
import dark from "./tokens/dark.json";
import enterprise from "./tokens/enterprise.json";
import enterpriseDark from "./tokens/enterprise-dark.json";
import enterpriseLight from "./tokens/enterprise-light.json";
import forestDark from "./tokens/forest-dark.json";
import forestLight from "./tokens/forest-light.json";
import gildedDark from "./tokens/gilded-dark.json";
import gildedLight from "./tokens/gilded-light.json";
import graphiteDark from "./tokens/graphite-dark.json";
import graphiteLight from "./tokens/graphite-light.json";
import indigoDark from "./tokens/indigo-dark.json";
import indigoLight from "./tokens/indigo-light.json";
import light from "./tokens/light.json";
import mintDark from "./tokens/mint-dark.json";
import mintLight from "./tokens/mint-light.json";
import oceanDark from "./tokens/ocean-dark.json";
import oceanLight from "./tokens/ocean-light.json";
import roseDark from "./tokens/rose-dark.json";
import roseLight from "./tokens/rose-light.json";
import slateDark from "./tokens/slate-dark.json";
import slateLight from "./tokens/slate-light.json";

export const tokenSets = {
  core,
  "amber-dark": amberDark,
  "amber-light": amberLight,
  "apex-dark": apexDark,
  "apex-light": apexLight,
  "concept-dark": conceptDark,
  "concept-light": conceptLight,
  light,
  dark,
  enterprise,
  "enterprise-dark": enterpriseDark,
  "enterprise-light": enterpriseLight,
  "forest-dark": forestDark,
  "forest-light": forestLight,
  "gilded-dark": gildedDark,
  "gilded-light": gildedLight,
  "graphite-dark": graphiteDark,
  "graphite-light": graphiteLight,
  "indigo-dark": indigoDark,
  "indigo-light": indigoLight,
  "mint-dark": mintDark,
  "mint-light": mintLight,
  "ocean-dark": oceanDark,
  "ocean-light": oceanLight,
  "rose-dark": roseDark,
  "rose-light": roseLight,
  "slate-dark": slateDark,
  "slate-light": slateLight
} as const;

export type TokenSetName = keyof typeof tokenSets;
