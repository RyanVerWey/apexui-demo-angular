import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import { basename, dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const sourceDir = resolve(root, "src/tokens");
const distDir = resolve(root, "dist");

const core = await readJson("core.json");
const sets = await readThemeSets();

validateTokens(core, sets);

const css = [
  ":root {",
  ...toCssVars({ ...core, ...sets.light }),
  "}",
  "",
  ...Object.entries(sets).flatMap(([name, tokens]) => [
    `[data-apex-theme="${name}"] {`,
    ...toCssVars(tokens),
    "}",
    ""
  ])
].join("\n");

await mkdir(distDir, { recursive: true });
await writeFile(resolve(distDir, "tokens.css"), `${css}\n`);
await writeFile(resolve(distDir, "tokens.json"), `${JSON.stringify({ core, sets }, null, 2)}\n`);
await writeFile(
  resolve(distDir, "index.js"),
  `export const tokenSets = ${JSON.stringify({ core, ...sets }, null, 2)};\n`
);
await writeFile(
  resolve(distDir, "index.d.ts"),
  [
    "export type TokenValue = string | { readonly [key: string]: TokenValue };",
    "export declare const tokenSets: {",
    "  readonly core: TokenValue;",
    ...Object.keys(sets).map((name) => `  readonly ${JSON.stringify(name)}: TokenValue;`),
    "};",
    "export type TokenSetName = keyof typeof tokenSets;",
    ""
  ].join("\n")
);

if (process.argv.includes("--check")) {
  console.info("Token validation passed.");
}

async function readJson(file) {
  return JSON.parse(await readFile(resolve(sourceDir, file), "utf8"));
}

async function readThemeSets() {
  const tokenFiles = (await readdir(sourceDir))
    .filter((file) => file.endsWith(".json") && file !== "core.json")
    .sort((a, b) => a.localeCompare(b));
  const entries = await Promise.all(
    tokenFiles.map(async (file) => [basename(file, ".json"), await readJson(file)])
  );

  return Object.fromEntries(entries);
}

function toCssVars(tokens, path = []) {
  return Object.entries(tokens).flatMap(([key, value]) => {
    const nextPath = [...path, key];
    if (typeof value === "string") {
      return `  --apex-${kebab(nextPath.join("-"))}: ${value};`;
    }

    return toCssVars(value, nextPath);
  });
}

function kebab(value) {
  return value.replace(/[A-Z]/g, (match) => `-${match.toLowerCase()}`);
}

function validateTokens(coreTokens, themeSets) {
  const requiredCore = ["space", "radius", "font", "motion", "shadow", "component"];
  const requiredColorRoles = [
    "canvas",
    "surface",
    "subtle",
    "text",
    "muted",
    "border",
    "accent",
    "accentStrong",
    "onAccent",
    "danger",
    "success",
    "warning",
    "info",
    "onDanger",
    "onSuccess",
    "onWarning",
    "onInfo"
  ];

  const missingCore = requiredCore.filter((key) => !(key in coreTokens));
  if (missingCore.length > 0) {
    throw new Error(`Missing core token groups: ${missingCore.join(", ")}`);
  }

  validateThemeFamilies(themeSets);

  for (const [setName, tokens] of Object.entries(themeSets)) {
    const colors = tokens.color ?? {};
    const missingColors = requiredColorRoles.filter((role) => !(role in colors));
    if (missingColors.length > 0) {
      throw new Error(`${setName} is missing color roles: ${missingColors.join(", ")}`);
    }

    validateContrast(setName, colors);
  }
}

function validateThemeFamilies(themeSets) {
  const families = Object.keys(themeSets).reduce((acc, name) => {
    const match = name.match(/^(.+)-(light|dark)$/);
    if (match) {
      const [, family, mode] = match;
      acc[family] ??= new Set();
      acc[family].add(mode);
    }

    return acc;
  }, {});

  const completeFamilies = Object.entries(families).filter(
    ([, modes]) => modes.has("light") && modes.has("dark")
  );
  if (completeFamilies.length < 10) {
    throw new Error(`Expected at least 10 complete light/dark theme families, found ${completeFamilies.length}.`);
  }
}

function validateContrast(setName, colors) {
  const pairs = [
    ["text", "canvas", 4.5],
    ["text", "surface", 4.5],
    ["muted", "surface", 4.5],
    ["onAccent", "accent", 4.5],
    ["onDanger", "danger", 4.5],
    ["onSuccess", "success", 4.5],
    ["onWarning", "warning", 4.5],
    ["onInfo", "info", 4.5]
  ];

  const failures = pairs.flatMap(([foreground, background, minimum]) => {
    const ratio = contrastRatio(colors[foreground], colors[background]);
    return ratio < minimum
      ? [`${foreground} on ${background}: ${ratio.toFixed(2)}:1, expected ${minimum}:1`]
      : [];
  });

  if (failures.length > 0) {
    throw new Error(`${setName} has contrast failures:\n- ${failures.join("\n- ")}`);
  }
}

function contrastRatio(foreground, background) {
  const foregroundLuminance = relativeLuminance(hexToRgb(foreground));
  const backgroundLuminance = relativeLuminance(hexToRgb(background));
  const lighter = Math.max(foregroundLuminance, backgroundLuminance);
  const darker = Math.min(foregroundLuminance, backgroundLuminance);

  return (lighter + 0.05) / (darker + 0.05);
}

function relativeLuminance([red, green, blue]) {
  const [r, g, b] = [red, green, blue].map((channel) => {
    const normalized = channel / 255;
    return normalized <= 0.03928
      ? normalized / 12.92
      : ((normalized + 0.055) / 1.055) ** 2.4;
  });

  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function hexToRgb(hex) {
  const normalized = hex.replace("#", "");
  if (!/^[0-9a-fA-F]{6}$/.test(normalized)) {
    throw new Error(`Expected 6-digit hex color, received ${hex}`);
  }

  return [
    Number.parseInt(normalized.slice(0, 2), 16),
    Number.parseInt(normalized.slice(2, 4), 16),
    Number.parseInt(normalized.slice(4, 6), 16)
  ];
}
