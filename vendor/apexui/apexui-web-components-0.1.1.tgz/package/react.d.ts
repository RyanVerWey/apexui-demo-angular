import type * as React from "react";

type BooleanAttribute = boolean | "true" | "false" | "";

type ApexCustomElementProps<Element, Props> = React.DetailedHTMLProps<
  React.HTMLAttributes<Element> & Props,
  Element
>;

declare module "react" {
  namespace JSX {
    interface IntrinsicElements {
      "apex-accordion": ApexCustomElementProps<
        HTMLElement,
        {
          heading?: string;
          open?: BooleanAttribute;
        }
      >;
      "apex-app-bar": ApexCustomElementProps<
        HTMLElement,
        {
          heading?: string;
        }
      >;
      "apex-autocomplete": ApexCustomElementProps<
        HTMLElement,
        {
          hint?: string;
          label: string;
          onApexChange?: (event: CustomEvent<{ value: string }>) => void;
          options?: string[] | string;
          placeholder?: string;
          value?: string;
        }
      >;
      "apex-alert": ApexCustomElementProps<
        HTMLElement,
        {
          heading?: string;
          tone?: "info" | "success" | "warning" | "danger";
        }
      >;
      "apex-avatar": ApexCustomElementProps<
        HTMLElement,
        {
          alt?: string;
          initials?: string;
          size?: "sm" | "md" | "lg";
          src?: string;
        }
      >;
      "apex-badge": ApexCustomElementProps<
        HTMLElement,
        {
          tone?: "neutral" | "info" | "success" | "warning" | "danger";
        }
      >;
      "apex-breadcrumbs": ApexCustomElementProps<
        HTMLElement,
        {
          items?: Array<{ current?: boolean; href?: string; label: string }> | string;
          label?: string;
        }
      >;
      "apex-checkbox": ApexCustomElementProps<
        HTMLElement,
        {
          checked?: BooleanAttribute;
          description?: string;
          disabled?: BooleanAttribute;
          label: string;
          name?: string;
          onApexChange?: (event: CustomEvent<{ checked: boolean }>) => void;
        }
      >;
      "apex-button": ApexCustomElementProps<
        HTMLElement,
        {
          disabled?: BooleanAttribute;
          "full-width"?: BooleanAttribute;
          fullWidth?: BooleanAttribute;
          size?: "sm" | "md" | "lg";
          type?: "button" | "submit" | "reset";
          variant?: "primary" | "secondary" | "danger";
        }
      >;
      "apex-button-group": ApexCustomElementProps<
        HTMLElement,
        {
          label: string;
        }
      >;
      "apex-card": ApexCustomElementProps<
        HTMLElement,
        {
          eyebrow?: string;
          heading?: string;
        }
      >;
      "apex-chart": ApexCustomElementProps<
        HTMLElement,
        {
          data?: Array<{ label: string; value: number }> | string;
          label?: string;
        }
      >;
      "apex-chip": ApexCustomElementProps<
        HTMLElement,
        {
          selected?: BooleanAttribute;
        }
      >;
      "apex-container": ApexCustomElementProps<
        HTMLElement,
        {
          size?: "sm" | "md" | "lg" | "full";
        }
      >;
      "apex-data-grid": ApexCustomElementProps<
        HTMLElement,
        {
          caption: string;
          columns?: Array<{ key: string; header: string }> | string;
          rows?: Array<Record<string, string | number | boolean | null | undefined>> | string;
        }
      >;
      "apex-data-table": ApexCustomElementProps<
        HTMLElement,
        {
          caption: string;
          columns?: Array<{ key: string; header: string }> | string;
          rows?: Array<Record<string, string | number | boolean | null | undefined>> | string;
        }
      >;
      "apex-date-picker": ApexCustomElementProps<
        HTMLElement,
        {
          hint?: string;
          label: string;
          name?: string;
          value?: string;
        }
      >;
      "apex-dialog": ApexCustomElementProps<
        HTMLElement,
        {
          description?: string;
          heading?: string;
          onApexClose?: (event: CustomEvent<void>) => void;
          open?: BooleanAttribute;
        }
      >;
      "apex-divider": ApexCustomElementProps<
        HTMLElement,
        {
          decorative?: BooleanAttribute;
          label?: string;
          orientation?: "horizontal" | "vertical";
        }
      >;
      "apex-drawer": ApexCustomElementProps<
        HTMLElement,
        {
          heading?: string;
          onApexClose?: (event: CustomEvent<void>) => void;
          open?: BooleanAttribute;
          side?: "left" | "right";
        }
      >;
      "apex-grid": ApexCustomElementProps<
        HTMLElement,
        {
          columns?: "auto" | "two" | "three" | "four";
        }
      >;
      "apex-image-list": ApexCustomElementProps<
        HTMLElement,
        {
          columns?: "two" | "three" | "four";
          items?: Array<{ alt: string; caption?: string; src: string }> | string;
        }
      >;
      "apex-list": ApexCustomElementProps<
        HTMLElement,
        {
          ordered?: BooleanAttribute;
        }
      >;
      "apex-masonry": ApexCustomElementProps<
        HTMLElement,
        {
          columns?: "two" | "three" | "four";
        }
      >;
      "apex-menu": ApexCustomElementProps<
        HTMLElement,
        {
          label?: string;
        }
      >;
      "apex-menubar": ApexCustomElementProps<
        HTMLElement,
        {
          label?: string;
        }
      >;
      "apex-paper": ApexCustomElementProps<
        HTMLElement,
        {
          elevation?: "none" | "sm" | "md";
        }
      >;
      "apex-pagination": ApexCustomElementProps<
        HTMLElement,
        {
          count?: number | string;
          label?: string;
          onApexChange?: (event: CustomEvent<{ page: number }>) => void;
          page?: number | string;
        }
      >;
      "apex-progress": ApexCustomElementProps<
        HTMLElement,
        {
          label: string;
          value?: number | string;
        }
      >;
      "apex-radio-group": ApexCustomElementProps<
        HTMLElement,
        {
          label: string;
          name: string;
          onApexChange?: (event: CustomEvent<{ value: string }>) => void;
          options?: Array<{ label: string; value: string; description?: string }> | string;
          value?: string;
        }
      >;
      "apex-rating": ApexCustomElementProps<
        HTMLElement,
        {
          label: string;
          max?: number | string;
          onApexChange?: (event: CustomEvent<{ value: number }>) => void;
          value?: number | string;
        }
      >;
      "apex-search-form": ApexCustomElementProps<
        HTMLElement,
        {
          label: string;
          placeholder?: string;
          "submit-label"?: string;
          submitLabel?: string;
          onApexSubmit?: (event: CustomEvent<{ query: string }>) => void;
        }
      >;
      "apex-select": ApexCustomElementProps<
        HTMLElement,
        {
          disabled?: BooleanAttribute;
          hint?: string;
          label: string;
          name?: string;
          onApexChange?: (event: CustomEvent<{ value: string }>) => void;
          options?: Array<{ label: string; value: string }> | string;
          value?: string;
        }
      >;
      "apex-skeleton": ApexCustomElementProps<
        HTMLElement,
        {
          label?: string;
          size?: "sm" | "md" | "lg";
          variant?: "text" | "rectangular" | "circle";
        }
      >;
      "apex-slider": ApexCustomElementProps<
        HTMLElement,
        {
          label: string;
          max?: number | string;
          min?: number | string;
          onApexChange?: (event: CustomEvent<{ value: number }>) => void;
          step?: number | string;
          value?: number | string;
        }
      >;
      "apex-snackbar": ApexCustomElementProps<
        HTMLElement,
        {
          open?: BooleanAttribute;
          tone?: "info" | "success" | "warning" | "danger";
        }
      >;
      "apex-stack": ApexCustomElementProps<
        HTMLElement,
        {
          align?: "start" | "center" | "stretch";
          direction?: "row" | "column";
          gap?: "sm" | "md" | "lg";
        }
      >;
      "apex-stepper": ApexCustomElementProps<
        HTMLElement,
        {
          "active-index"?: number | string;
          activeIndex?: number | string;
          steps?: Array<{ description?: string; id: string; label: string }> | string;
        }
      >;
      "apex-switch": ApexCustomElementProps<
        HTMLElement,
        {
          checked?: BooleanAttribute;
          description?: string;
          disabled?: BooleanAttribute;
          label: string;
          name?: string;
          onApexChange?: (event: CustomEvent<{ checked: boolean }>) => void;
        }
      >;
      "apex-tabs": ApexCustomElementProps<
        HTMLElement,
        {
          "active-id"?: string;
          activeId?: string;
          items?: Array<{ id: string; label: string }> | string;
          label: string;
          onApexChange?: (event: CustomEvent<{ id: string }>) => void;
        }
      >;
      "apex-time-picker": ApexCustomElementProps<
        HTMLElement,
        {
          hint?: string;
          label: string;
          name?: string;
          value?: string;
        }
      >;
      "apex-timeline": ApexCustomElementProps<
        HTMLElement,
        {
          events?: Array<{ description?: string; id: string; label: string; meta?: string }> | string;
        }
      >;
      "apex-tooltip": ApexCustomElementProps<
        HTMLElement,
        {
          label?: string;
        }
      >;
      "apex-toggle-group": ApexCustomElementProps<
        HTMLElement,
        {
          label: string;
          onApexChange?: (event: CustomEvent<{ value: string }>) => void;
          options?: Array<{ label: string; value: string }> | string;
          value?: string;
        }
      >;
      "apex-typography": ApexCustomElementProps<
        HTMLElement,
        {
          as?: "p" | "span" | "strong" | "small" | "h1" | "h2" | "h3" | "h4";
          variant?: "display" | "title" | "subtitle" | "body" | "caption";
        }
      >;
      "apex-tree-view": ApexCustomElementProps<
        HTMLElement,
        {
          items?: Array<{ children?: Array<{ id: string; label: string }>; id: string; label: string }> | string;
          label?: string;
        }
      >;
      "apex-workflow-board": ApexCustomElementProps<
        HTMLElement,
        {
          columns?: Array<{ id: string; items: Array<{ id: string; meta?: string; title: string }>; title: string }> | string;
        }
      >;
      "apex-text-field": ApexCustomElementProps<
        HTMLElement,
        {
          disabled?: BooleanAttribute;
          error?: string;
          hint?: string;
          label: string;
          name?: string;
          placeholder?: string;
          type?: string;
          value?: string;
        }
      >;
    }
  }
}

export {};
